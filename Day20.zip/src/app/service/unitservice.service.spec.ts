import { TestBed } from '@angular/core/testing';

import { UnitserviceService } from './unitservice.service';

describe('UnitserviceService', () => {
  let service: UnitserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UnitserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
