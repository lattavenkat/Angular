import { TestBed } from '@angular/core/testing';

import { GetmydataService } from './getmydata.service';

describe('GetmydataService', () => {
  let service: GetmydataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetmydataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
