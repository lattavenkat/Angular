import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class ForexserviceService {
  
    
  public InrToUsd(amount:number)
  {
    return amount*0.014;
  }
  public UsdToInr(amount:number)
  {
    return amount*0.014/0.014;
  }
  constructor() { }
}
