import { TestBed } from '@angular/core/testing';

import { ForexserviceService } from './forexservice.service';

describe('ForexserviceService', () => {
  let service: ForexserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ForexserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
