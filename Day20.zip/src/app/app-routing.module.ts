import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ForexcalComponent } from './components/forexcal/forexcal.component';
import { FradulentpaymentserviceComponent } from './components/fradulentpaymentservice/fradulentpaymentservice.component';
import { LoginComponent } from './components/login/login.component';
import { PaymentPayloadServiceComponent } from './components/payment-payload-service/payment-payload-service.component';
import { UnitconversionComponent } from './components/unitconversion/unitconversion.component';

const routes: Routes = [{path:'login',component:LoginComponent},{path:'dashboard',component:DashboardComponent},
{path:'',redirectTo:'/login',pathMatch:'full'},{path:'forexcal',component:ForexcalComponent},{path:'unitcon',component:UnitconversionComponent},{path:'payloadservice',component:PaymentPayloadServiceComponent},{path:'fraudulent',component:FradulentpaymentserviceComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

