import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForexcalComponent } from './forexcal.component';

describe('ForexcalComponent', () => {
  let component: ForexcalComponent;
  let fixture: ComponentFixture<ForexcalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForexcalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForexcalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
