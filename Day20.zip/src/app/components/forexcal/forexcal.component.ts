import { Component, OnInit } from '@angular/core';
import { ForexserviceService } from 'src/app/service/forexservice.service';

@Component({
  selector: 'app-forexcal',
  templateUrl: './forexcal.component.html',
  styleUrls: ['./forexcal.component.css']
})
export class ForexcalComponent implements OnInit {
  selectedFrom:String='';
  selectedTo:String='';
  amount:number=0;
  resamt:number=0;
  private fserv: ForexserviceService=new ForexserviceService();

  from(e:any)
  {
    this.selectedFrom=e.target.value;
  }
  to(e:any)
  {
    this.selectedTo=e.target.value;
  }

  cal()
  {
    if(this.selectedFrom=='INR' && this.selectedTo=='USD')
    {
      this.resamt=this.fserv.InrToUsd(this.amount); 
    }
    else if(this.selectedFrom=='USD' && this.selectedTo=='INR')
    {
      this.resamt=this.fserv.UsdToInr(this.amount); 
    }
    else
    {
      this.resamt=this.amount;
    }
  }
  constructor() { }
  ngOnInit(): void {
  }

}
