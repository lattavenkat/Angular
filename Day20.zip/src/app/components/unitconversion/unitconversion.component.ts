import { Component, OnInit } from '@angular/core';
import { UnitserviceService } from 'src/app/service/unitservice.service';

@Component({
  selector: 'app-unitconversion',
  templateUrl: './unitconversion.component.html',
  styleUrls: ['./unitconversion.component.css']
})
export class UnitconversionComponent implements OnInit {
  selectedfrom:String='';
  selectedto:String='';
  valuein:number=0;
  resunit:number=0;
  private userv: UnitserviceService=new UnitserviceService();
  from(e:any)
  {
    this.selectedfrom=e.target.value;
  }
  to(e:any)
  {
    this.selectedto=e.target.value;
  }
  cal()
    {
    if(this.selectedfrom=='CM' && this.selectedto=='M')
    {
       this.resunit=this.userv.cmTom(this.valuein);
    }
    else if(this.selectedfrom=='CM' && this.selectedto=='FEET')
    {
      this.resunit=this.userv.cmTofeet(this.valuein); 
    }
    else if(this.selectedfrom=='FEET' && this.selectedto=='CM')
    {
      this.resunit=this.userv.feetTocm(this.valuein); 
    }
    else if(this.selectedfrom=='FEET' && this.selectedto=='M')
    {
      this.resunit=this.userv.feetTom(this.valuein); 
    }
    else if(this.selectedfrom=='M' && this.selectedto=='CM')
    {
      this.resunit=this.userv.mTocm(this.valuein); 
    }
    else if(this.selectedfrom=='M' && this.selectedto=='FEET')
    {
      this.resunit=this.userv.mTofeet(this.valuein); 
    }
    else
    {
      this.resunit=this.valuein;
    }
    
  }
  constructor() { }

  ngOnInit(): void {
  }

}
