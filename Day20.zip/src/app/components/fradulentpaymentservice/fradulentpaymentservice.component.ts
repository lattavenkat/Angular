import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fradulentpaymentservice',
  templateUrl: './fradulentpaymentservice.component.html',
  styleUrls: ['./fradulentpaymentservice.component.css']
})
export class FradulentpaymentserviceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
