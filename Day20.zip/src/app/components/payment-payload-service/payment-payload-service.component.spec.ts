import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentPayloadServiceComponent } from './payment-payload-service.component';

describe('PaymentPayloadServiceComponent', () => {
  let component: PaymentPayloadServiceComponent;
  let fixture: ComponentFixture<PaymentPayloadServiceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaymentPayloadServiceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentPayloadServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
