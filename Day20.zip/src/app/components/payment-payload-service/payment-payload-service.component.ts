import { Component, OnInit } from '@angular/core';
import { GetmydataService } from 'src/app/service/getmydata.service';

@Component({
  selector: 'app-payment-payload-service',
  templateUrl: './payment-payload-service.component.html',
  styleUrls: ['./payment-payload-service.component.css']
})
export class PaymentPayloadServiceComponent implements OnInit {
  Display(){
    this.serv.getData().subscribe((data)=>{console.log(data)});
  }
  constructor(private serv:GetmydataService){}
  ngOnInit(): void {
  }
}
