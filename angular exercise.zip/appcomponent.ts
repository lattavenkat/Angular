import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'MyApp';
  fName:String;
  lName:String;
  name:String;    
  uName:String;
  course:String;
  public unicorn1:string="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQcHCKUyS0-WmYL6eDXqKdAJjrj9vj7LaTmBA&usqp=CAU";
  public unicorn2:string="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDI1NkyFDs0lM-NNsG4SYNGTU_b-eJo2hfNw&usqp=CAU";
  ButtonEvent(event) { 
    alert('WELCOME'); 
   } 
   onKey(e){
    console.log(e.target.vlaue);
   }
   onKeyenter(e){
    console.log(e.target.vlaue);
   }
   refmeth(fName,lName,course){
      console.log("First name" +fName+ " Last Name"+lName);
      console.log("Selcted course is: " +course);
   }
  constructor(){
    setTimeout(()=>{
      this.unicorn1=this.unicorn2;
      this.title="welcome to angular";
      console.log("First Angular Project!");
    },4000);

  }
}


